package com.javatechig.customizedlist;

/**
 * Created by cfit004 on 27/6/16.
 */

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.example.customizedlist.R;

import java.util.ArrayList;

public class NextActivity extends Activity {


    int pos =0;
    Intent i;
String pos1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next);

        Intent i = getIntent();
ListItem data=(ListItem) i.getSerializableExtra("key");
        GridView gridview = (GridView) findViewById(R.id.gridview);
        gridview.setAdapter(new ImageAdapter(this));

        final ImageView iv1=(ImageView)findViewById(R.id.imageView1);
       final TextView tv1 = (TextView) findViewById(R.id.textView4);
        final TextView tv2 = (TextView) findViewById(R.id.textView5);
        final TextView tv3 = (TextView) findViewById(R.id.textView6);

         String[] images = getResources().getStringArray(R.array.images_array);
        String[] headlines = getResources().getStringArray(R.array.headline_array);


        for(int x=0;x<images.length/2; x++) {
            if (data.getReporterName().equals(images[x+5]))
                pos=x;

        }

        new ImageDownloaderTask(iv1).execute(data.getUrl());

        tv1.setText("Starting at Rs. "+images[pos+5]+" /-");

        tv2.setText(""+headlines[pos]);
      // tv3.setText(""+headlines[pos+5]);





    }

}